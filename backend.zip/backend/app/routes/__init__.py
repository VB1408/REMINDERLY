# This file marks the routes directory as a Python package

from .auth_routes import router as auth_routes
from .reminder_routes import router as reminder_routes

__all__ = ["auth_routes", "reminder_routes"]
