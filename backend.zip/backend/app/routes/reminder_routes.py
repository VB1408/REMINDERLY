from fastapi import APIRouter, Depends, HTTPException, status, Request
from sqlmodel import Session
from typing import List, Optional
from app.database import get_db
from app.models import Reminder, User
from app.auth import oauth2_scheme, get_current_user
from pydantic import BaseModel
from datetime import datetime
import logging

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

router = APIRouter()

class ReminderCreate(BaseModel):
    title: str
    description: Optional[str] = None
    due_date: datetime

@router.post("/", response_model=Reminder)
async def create_reminder(
    request: Request,
    reminder_data: ReminderCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    try:
        with get_db() as db:
            # Log the incoming data
            logger.info(f"Received reminder data: {reminder_data.dict()}")
            logger.info(f"Current user: {current_user.email}")

            # Create the reminder
            reminder = Reminder(
                title=reminder_data.title,
                description=reminder_data.description,
                due_date=reminder_data.due_date,
                user_id=current_user.id
            )
            
            # Add to database
            db.add(reminder)
            db.commit()
            db.refresh(reminder)
            
            logger.info(f"Successfully created reminder: {reminder.id}")
            return reminder
    except Exception as e:
        logger.error(f"Error creating reminder: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e)
        )

@router.get("/", response_model=List[Reminder])
def get_reminders(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    with get_db() as db:
        return db.query(Reminder).filter(Reminder.user_id == current_user.id).all()

@router.get("/{reminder_id}", response_model=Reminder)
def get_reminder(
    reminder_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    with get_db() as db:
        reminder = db.query(Reminder).filter(
            Reminder.id == reminder_id,
            Reminder.user_id == current_user.id
        ).first()
        if not reminder:
            raise HTTPException(status_code=404, detail="Reminder not found")
        return reminder

@router.put("/{reminder_id}", response_model=Reminder)
def update_reminder(
    reminder_id: int,
    reminder_data: ReminderCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    with get_db() as db:
        db_reminder = db.query(Reminder).filter(
            Reminder.id == reminder_id,
            Reminder.user_id == current_user.id
        ).first()
        if not db_reminder:
            raise HTTPException(status_code=404, detail="Reminder not found")
        
        for key, value in reminder_data.dict(exclude_unset=True).items():
            setattr(db_reminder, key, value)
        
        db.commit()
        db.refresh(db_reminder)
        return db_reminder

@router.delete("/{reminder_id}")
def delete_reminder(
    reminder_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    with get_db() as db:
        reminder = db.query(Reminder).filter(
            Reminder.id == reminder_id,
            Reminder.user_id == current_user.id
        ).first()
        if not reminder:
            raise HTTPException(status_code=404, detail="Reminder not found")
        
        db.delete(reminder)
        db.commit()
        return {"message": "Reminder deleted successfully"}
