from typing import Optional
from datetime import datetime
from sqlmodel import Field, SQLModel, Relationship

# ============================
# Base User model for reuse
# ============================
class User(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    email: str = Field(unique=True, index=True)
    hashed_password: str
    is_active: bool = Field(default=True)
    created_at: datetime = Field(default_factory=datetime.utcnow)

    # Back-reference to reminders
    reminders: list["Reminder"] = Relationship(back_populates="user")


# ============================
# Reminder model
# ============================
class Reminder(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    title: str
    description: Optional[str] = None
    due_date: datetime
    is_completed: bool = Field(default=False)
    user_id: int = Field(foreign_key="user.id")
    created_at: datetime = Field(default_factory=datetime.utcnow)

    user: Optional[User] = Relationship(back_populates="reminders")
